import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import json
import os
import time
import numpy as np
from datetime import datetime

# --- 1. 页面基础配置 ---
st.set_page_config(page_title="ES 0DTE 全功能看板", layout="wide", initial_sidebar_state="collapsed")

# 注入 CSS：修复标题消失与组件重叠
st.markdown("""
    <style>
    /* 1. 整体容器优化 */
    .block-container { padding-top: 3.0rem !important; padding-bottom: 0rem !important; }
    
    /* 2. 修复标题显示：确保 markdown 标题有足够高度且不被遮挡 */
    .element-container:has(h3) { margin-bottom: 5px !important; }
    h3 { padding: 5px 0px !important; margin: 0px !important; line-height: 1.5 !important; font-size: 1.75rem !important; overflow: visible !important; }

    /* 3. 核心指标与信号栏：压缩间距但保留底部余地 */
    [data-testid="stMetric"] { padding: 5px 0px !important; }
    .stAlert { margin-top: 0px !important; padding: 0.5rem !important; border: 1px solid #e1e4e8 !important; }
    
    /* 4. 分割线与图表：防止与下方标题重叠 */
    hr { margin-top: 10px !important; margin-bottom: 15px !important; }
    .stPlotlyChart { margin-bottom: 20px !important; } /* 关键：给图表下方留出 20px 空间 */

    /* 5. 确保表格标题清晰可见 */
    .element-container:has(h4) { margin-top: 10px !important; }
    </style>
    """, unsafe_allow_html=True)

# --- 2. 加载数据 ---

def load_json_data():
    try:
        if os.path.exists("gex_data.json"):
            with open("gex_data.json", "r") as f: return json.load(f)
    except: return None

def get_daily_filename(base_name):
    """生成带日期的文件名，例如 20260126_gex_history.csv"""
    date_str = datetime.now().strftime("%Y%m%d")
    return f"{date_str}_{base_name}"

def load_csv_data(file):
    daily_file = get_daily_filename(file)
    if os.path.exists(daily_file):
        try: return pd.read_csv(daily_file).replace([np.inf, -np.inf], np.nan)
        except: return pd.DataFrame()
    return pd.DataFrame()

# --- 3. 页面渲染 ---
data = load_json_data()
df_history = load_csv_data("gex_history.csv")
df_snapshot = load_csv_data("options_snapshot.csv")

if data:
    current_spot = data['spot'] 
    # 使用紧凑型标题
    st.markdown(f"## 📈 SPY 实时对冲监控系统 ({data.get('time', 'N/A')})")
    
    # --- 第一部分：顶部核心指标 (横向撑满) ---
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("SPY Price", f"${data['spot']:.2f}")
    m2.metric("Gamma Flip", f"${data['flip']:.2f}" if data['flip'] else "N/A")
    
    gex_val = data['total_gex'] / 1e6
    gex_delta = 0
    if not df_history.empty and len(df_history) > 1:
        prev_gex = df_history['total_gex'].iloc[-2] / 1e6
        gex_delta = gex_val - prev_gex
    
    m3.metric("Total GEX", f"{gex_val:.1f}M", delta=f"{gex_delta:.1f}M")
    m4.metric("Avg IV", f"{data.get('last_avg_iv', 0)*100:.2f}%")
    m5.metric("Strategy", data['action'].split("(")[0]) 

    # --- 第二部分：横向平铺三列信号栏 ---
    s1, s2, s3 = st.columns(3)
    with s1:
        st.info(f"**信号:** {data['signal']}")
    with s2:
        gex_val_raw = data['total_gex'] / 1e6
        if gex_val_raw < 0:
            st.error(f"⚠️ **Short Gamma**: 波动正反馈")
        else:
            st.success(f"✅ **Long Gamma**: 均值回归")
    with s3:
        st.warning(f"**状态:** {data['action']}")

    # 紧凑型分割线
    st.markdown("<hr>", unsafe_allow_html=True)
    st.subheader("📈 价格与 GEX 趋势 (Vanna 分析)")
    # --- 第三部分：趋势图 (紧凑型) ---
    if not df_history.empty:
        
        df_history['timestamp'] = pd.to_datetime(df_history['timestamp'])
        fig = make_subplots(specs=[[{"secondary_y": True}]])
        fig.add_trace(go.Scatter(x=df_history['timestamp'], y=df_history['total_gex'], 
                                 name="Total GEX", fill='tozeroy', line=dict(color='green', width=1)), secondary_y=False)
        fig.add_trace(go.Scatter(x=df_history['timestamp'], y=df_history['spot'], 
                                 name="SPY Price", line=dict(color='blue', width=2)), secondary_y=True)
        
        # 移除图表内部所有边距
        fig.update_layout(height=350, template="plotly_white", 
                          margin=dict(l=0, r=0, t=10, b=0),
                          legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
        st.plotly_chart(fig, use_container_width=True, key="main_trend")

    st.divider()

    # --- 第三部分：平值上下 5 档阶梯 ---
    st.subheader("🎯 SPY 核心对冲区间 (平值上下5档)")
    if not df_snapshot.empty:
        latest_ts = df_snapshot['timestamp'].iloc[-1]
        df_latest = df_snapshot[df_snapshot['timestamp'] == latest_ts].copy()
        exps = sorted(df_latest['expiry'].unique())
        
        def render_precise_ladder(df_sub, spot_price):
            if df_sub.empty: return
            # 去重
            df_sub = df_sub.sort_values('oi', ascending=False).drop_duplicates(['strike', 'right'])
            # 构建阶梯
            calls = df_sub[df_sub['right'] == 'C'].set_index('strike')
            puts = df_sub[df_sub['right'] == 'P'].set_index('strike')
            ladder = calls.join(puts, how='outer', lsuffix='_c', rsuffix='_p').sort_index(ascending=False).reset_index()
            # 截取
            ladder['dist'] = (ladder['strike'] - spot_price).abs()
            atm_idx_pos = ladder['dist'].idxmin() 
            ladder_sliced = ladder.iloc[max(0, atm_idx_pos - 5):min(len(ladder), atm_idx_pos + 6)].copy()
            # 重命名
            disp_map = {'vol_c': 'C_Vol', 'oi_c': 'C_OI', 'gamma_c': 'C_Gam', 'delta_c': 'C_Del', 'price_c': 'C_Px',
                        'strike': 'STRIKE', 'price_p': 'P_Px', 'delta_p': 'P_Del', 'gamma_p': 'P_Gam', 'oi_p': 'P_OI', 'vol_p': 'P_Vol'}
            ladder_display = ladder_sliced[[c for c in disp_map.keys() if c in ladder_sliced.columns]].rename(columns=disp_map)
            # --- 新增：格式化配置 (针对交易员审阅习惯) ---
            # 1. Vol 和 OI 强制转为整数（去除小数点）
            # 2. 价格保留 2 位，Greeks 保留 3-4 位
            format_dict = {
                'C_Vol': '{:,.0f}', 'C_OI': '{:,.0f}', 'P_Vol': '{:,.0f}', 'P_OI': '{:,.0f}',
                'C_Px': '{:.2f}', 'P_Px': '{:.2f}',
                'C_Del': '{:.3f}', 'P_Del': '{:.3f}',
                'C_Gam': '{:.4f}', 'P_Gam': '{:.4f}',
                'STRIKE': '{:.1f}'
            }
            
            # 高亮
            new_atm_idx = (ladder_display['STRIKE'] - spot_price).abs().idxmin()
            
            # 链式应用：格式化 -> 高亮 -> 色阶
            styled = (ladder_display.style
                .format(format_dict, na_rep="-")  # 应用格式化并处理空值为横杠
                .apply(lambda s: ['background-color: #FFA500; color: black; font-weight: bold' if s.name == new_atm_idx else '' for _ in s], axis=1)
            )
            
            # 色阶 (需在 format 之后应用，因为 styled 对象会保持列名关联)
            if 'C_Del' in ladder_display.columns: styled = styled.background_gradient(subset=['C_Del','C_Gam'], cmap='RdYlGn')
            if 'P_Del' in ladder_display.columns: styled = styled.background_gradient(subset=['P_Del','P_Gam'], cmap='RdYlGn_r')
            
            st.dataframe(styled, use_container_width=True, height=420)
        sc1, sc2 = st.columns(2)
        with sc1:
            st.write(f"**今日 (T+0)**")
            if len(exps) > 0: render_precise_ladder(df_latest[df_latest['expiry'] == exps[0]], current_spot)
        with sc2:
            st.write(f"**次日 (T+1)**")
            if len(exps) > 1: render_precise_ladder(df_latest[df_latest['expiry'] == exps[1]], current_spot)
    else:
        st.info("阶梯明细载入中...")

else:
    st.warning("请检查 gex_monitor.py 是否已产生 gex_data.json 文件。")

# 自动刷新
time.sleep(5)
st.rerun()