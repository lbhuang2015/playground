# SPY_GEX_Monitor/gex_monitor.py
import os
import time
import asyncio
import datetime
import logging
import json
import numpy as np
import pandas as pd
from ib_insync import IB, util, Option, Stock
import nest_asyncio

# Apply nest_asyncio to allow running asyncio event loop within another one (e.g., in Jupyter or Spyder)
nest_asyncio.apply()

# --- Configuration ---
IBKR_HOST = '127.0.0.1'
IBKR_PORT = 7496  # 7497 for TWS, 4001 for Gateway
IBKR_CLIENT_ID = 1
# For performance, limit the strike range around the spot price, e.g., 10%
STRIKE_RANGE_PCT = 0.10 

# --- Logging Setup ---
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class SPYGEXMonitor:
    def __init__(self, host, port, client_id):
        self.last_log_time = 0
        self.ib = IB()
        self.host = host
        self.port = port
        self.client_id = client_id
        self.spy_contract = None
        self.spy_spot_price = None
        self.options_df = pd.DataFrame()
        self.gex_profile = pd.DataFrame()
        self.is_data_ready = asyncio.Event()
        self.last_avg_iv = 0.0
        # Load last average IV for simulation mode
        try:
            with open('gex_data.json', 'r') as f:
                data = json.load(f)
                self.last_avg_iv = data.get('last_avg_iv', 0.0)
                logging.info(f"Loaded last average IV: {self.last_avg_iv:.4f}")
        except (FileNotFoundError, json.JSONDecodeError):
            logging.warning("gex_data.json not found or invalid. Starting with default IV.")

    @staticmethod
    def _is_trading_hours():
        """Checks if current time is within regular US trading hours (9:30am - 4pm).
        NOTE: This is a simplified, timezone-naive check assuming the script runs in US/Eastern.
        """
        now = datetime.datetime.now().time()
        is_weekday = datetime.datetime.today().weekday() < 5  # Monday=0, Sunday=6
        is_market_time = datetime.time(9, 30) <= now <= datetime.time(16, 0)
        return is_weekday and is_market_time
        self.last_avg_iv = 0.0
        # Load last average IV for simulation mode
        try:
            with open('gex_data.json', 'r') as f:
                data = json.load(f)
                self.last_avg_iv = data.get('last_avg_iv', 0.0)
                logging.info(f"Loaded last average IV: {self.last_avg_iv:.4f}")
        except (FileNotFoundError, json.JSONDecodeError):
            logging.warning("gex_data.json not found or invalid. Starting with default IV.")

    async def connect(self):
        while not self.ib.isConnected():
            try:
                logging.info(f"Connecting to IBKR at {self.host}:{self.port}...")
                await self.ib.connectAsync(self.host, self.port, self.client_id)
            except Exception as e:
                logging.error(f"Connection failed: {e}. Retrying in 10s...")
                await asyncio.sleep(10)

    async def setup_contracts_and_data(self):
        logging.info("Setting up SPY contract and option chains...")
        
        # 1. Qualify SPY
        self.spy_contract = Stock('SPY', 'SMART', 'USD')
        await self.ib.qualifyContractsAsync(self.spy_contract)
        
        # 使用正确的 reqMktData
        spy_ticker = self.ib.reqMktData(self.spy_contract, '', False, False)
        while not spy_ticker.marketPrice() or np.isnan(spy_ticker.marketPrice()):
            logging.info("Waiting for SPY price...")
            await asyncio.sleep(1)
        
        self.spy_spot_price = spy_ticker.marketPrice()
        logging.info(f"Initial SPY Spot Price: {self.spy_spot_price}")

        # 2. 获取期权链参数 (增加容错)
        chains = await self.ib.reqSecDefOptParamsAsync(self.spy_contract.symbol, '', self.spy_contract.secType, self.spy_contract.conId)
        if not chains:
            logging.error("无法从 Gateway 获取期权链描述。")
            return

        best_chain = None
        max_exps = -1

        for c in chains:
            logging.info(f"发现链: 交易所={c.exchange}, TradingClass={c.tradingClass}, 到期日数量={len(c.expirations)}")
            # 筛选逻辑：必须是标准 SPY 类，且到期日最多的那个
            if c.tradingClass == 'SPY' and len(c.expirations) > max_exps:
                max_exps = len(c.expirations)
                best_chain = c

        if not best_chain:
            logging.error("未能识别到标准的 SPY 期权链。")
            return

        logging.info(f"选定最优链: 交易所={best_chain.exchange}, 包含 {len(best_chain.expirations)} 个到期日")
        
        # --- 修正逻辑 1：智能选择到期日 ---
        all_raw_exps = sorted(best_chain.expirations)
        all_raw_strikes = sorted(best_chain.strikes)
        today_str = datetime.date.today().strftime('%Y%m%d')
        target_exps = [e for e in all_raw_exps if e >= today_str][:2]
        logging.info(f"Gateway 返回的原始到期日数量: {len(all_raw_exps)}")
        logging.info(f"前 5 个原始到期日: {all_raw_exps[:5]}")
        logging.info(f"原始行权价数量: {len(all_raw_strikes)}")
        # 选取从今天开始（含今天）最近的 2 个到期日
        # 选取 Gateway 返回的、不早于今天的最近 2 个日期
        valid_exps = [e for e in all_raw_exps if e >= today_str][:2]
        
        if not valid_exps:
            logging.error(f"在期权链中未找到有效到期日。Gateway 返回的首个日期是: {all_raw_exps[0]}")
            return

        # --- 修正逻辑 2：行权价与合约构造 ---
        # 筛选当前价上下 5% 的 Strike
        strikes = [s for s in best_chain.strikes if self.spy_spot_price * 0.92 <= s <= self.spy_spot_price * 1.02]
        
        contracts = []
        for exp in valid_exps:
            for strike in strikes:
                for right in ['C', 'P']:
                    # 按照 Gateway 日志中的标准参数构造
                    contracts.append(Option(
                        symbol='SPY', 
                        lastTradeDateOrContractMonth=exp, 
                        strike=strike, 
                        right=right, 
                        exchange='SMART', 
                        multiplier='100', # 必须是字符串
                        currency='USD',
                        tradingClass='SPY' # 显式指定，防止混淆
                    ))

        logging.info(f"正在向 Gateway 验证 {len(contracts)} 个合约...")
        
        # 3. 资格化
        qualified = await self.ib.qualifyContractsAsync(*contracts)
        
        if not qualified:
            logging.error("资格化失败。请确认：1. TWS/Gateway 已登录 2. 具有 OPRA 行情权限 3. 系统时间正确。")
            return

        if qualified:
            # 强制将资格化后的合约转为 DF，并手动设置索引和列名
            self.options_df = util.df(qualified)
            
            # 打印列名以供调试，防止再次 KeyError
            logging.info(f"DataFrame 现有列名: {self.options_df.columns.tolist()}")
            
            # 如果列名被缩短了，我们要重命名回代码中使用的名字
            if 'lastTradeDateOrContractMonth' not in self.options_df.columns:
                # ib_insync 某些版本会将其转为 'lastTradeDateOrContractMonth'
                # 我们可以通过 conId 建立索引，这样后续查找更安全
                self.options_df.set_index('conId', inplace=True)
            
            logging.info(f"成功激活 {len(self.options_df)} 个合约")

        # 5. 构建 DataFrame
        self.options_df = util.df(qualified)
        self.options_df = self.options_df[['conId', 'symbol', 'lastTradeDateOrContractMonth', 'strike', 'right']]
        self.options_df.rename(columns={'lastTradeDateOrContractMonth': 'expiry'}, inplace=True)
        self.options_df.set_index('conId', inplace=True)
        
        for col in ['gamma', 'volume', 'openInterest', 'iv']:
            self.options_df[col] = 0.0

        # 6. 订阅数据 (genericTickList 101 为 Greeks)
        logging.info("Subscribing to Greeks...")
        for contract in qualified:
            self.ib.reqMktData(contract, '101,104,106', False, False)

        self.ib.pendingTickersEvent += self.on_pending_tickers
        self.is_data_ready.set()
        logging.info("Setup complete. Monitoring...")

    def get_daily_filename(self, base_name):
        """生成带日期的文件名，例如 20260126_gex_history.csv"""
        date_str = datetime.datetime.now().strftime("%Y%m%d")
        return f"{date_str}_{base_name}"
    
    def on_pending_tickers(self, tickers):
        if not self.is_data_ready.is_set(): 
            return
        
        for t in tickers:
            cId = t.contract.conId
            # 更新标的价格
            if cId == self.spy_contract.conId:
                if t.marketPrice(): 
                    self.spy_spot_price = t.marketPrice()
                continue
            
            # 更新期权数据
            if cId in self.options_df.index:
                # 1. 安全地获取 Greeks
                if t.modelGreeks:
                    self.options_df.loc[cId, 'gamma'] = t.modelGreeks.gamma if t.modelGreeks.gamma is not None else 0
                    self.options_df.loc[cId, 'iv'] = t.modelGreeks.impliedVol if t.modelGreeks.impliedVol is not None else 0
                
                # 2. 安全地获取 Open Interest (使用 getattr 防止 AttributeError)
                # IBKR 的持仓量通常在 openInterest 字段，如果没有则默认为 0
                oi = getattr(t, 'openInterest', 0)
                if oi is not None and not np.isnan(oi):
                    self.options_df.loc[cId, 'openInterest'] = oi
                
                # 3. 安全地获取 Volume
                vol = getattr(t, 'volume', 0)
                if vol is not None and not np.isnan(vol):
                    self.options_df.loc[cId, 'volume'] = vol

        # 触发 GEX 计算
        self.calculate_gex_profile()

    def log_options_snapshot(self, timestamp):
        """筛选近端平值期权的完整希腊字母记录"""
        if self.options_df.empty or self.spy_spot_price is None:
            return

        tickers = self.ib.tickers()
        snapshot_rows = []

        # 1. 动态获取到期日列表，不再依赖特定的列名
        # 我们直接从 options_df 的 values 中提取合约对象的属性
        all_contracts = self.options_df.index.tolist() # 假设索引是 conId
        
        # 获取唯一的到期日并排序
        all_exps = sorted(list(set([t.contract.lastTradeDateOrContractMonth for t in tickers if t.contract.secType == 'OPT'])))
        target_exps = all_exps[:2] if all_exps else []
        
        for t in tickers:
            c = t.contract
            if getattr(c, 'secType', '') != 'OPT': continue
            
            # 关键修复：直接从 contract 对象取属性，不查 DataFrame
            exp = getattr(c, 'lastTradeDateOrContractMonth', '')
            if exp not in target_exps: continue
            
            strike = getattr(c, 'strike', 0)
            if abs(strike - self.spy_spot_price) > 5: continue

            g = t.modelGreeks
            row = {
                "timestamp": timestamp,
                "symbol": getattr(c, 'localSymbol', 'N/A'),
                "expiry": exp,
                "strike": strike,
                "right": getattr(c, 'right', ''),
                "spot": self.spy_spot_price,
                "price": t.marketPrice(),
                "iv": g.impliedVol if g else np.nan,
                "delta": g.delta if g else np.nan,
                "gamma": g.gamma if g else np.nan,
                "vanna": getattr(g, 'vanna', np.nan) if g else np.nan,
                "charm": getattr(g, 'charm', np.nan) if g else np.nan,
                "oi": getattr(t, 'openInterest', 0),
                "vol": getattr(t, 'volume', 0)
            }
            snapshot_rows.append(row)

        if snapshot_rows:
            df_snap = pd.DataFrame(snapshot_rows)
            file_path = self.get_daily_filename('options_snapshot.csv')

            df_snap.to_csv(file_path, mode='a', index=False, header=not os.path.isfile(file_path))

    def update_outputs(self, data):
        """三维数据分发中心"""
        current_time = time.time()
        
        # --- 1. 实时 JSON (无闸门，保证 Dashboard 顺滑) ---
        try:
            with open("gex_data.json", "w") as f:
                json.dump(data, f)
        except Exception as e:
            logging.error(f"JSON 写入失败: {e}")

        # --- 2. 历史 CSV 闸门 (每 5 秒执行一次持久化) ---
        if current_time - self.last_log_time < 5:
            return

        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        # 记录 GEX 汇总趋势
        data["timestamp"] = now_str
        df_gex = pd.DataFrame([data])
        file_path = self.get_daily_filename('gex_history.csv')
        df_gex.to_csv(file_path, mode='a', index=False, header=not os.path.isfile(file_path))

        # 记录核心期权行情明细
        self.log_options_snapshot(now_str)

        self.last_log_time = current_time
        logging.info(f"[{now_str}] 宏观及微观数据已存入 CSV")

    def calculate_gex_profile(self):
        if self.options_df.empty or self.spy_spot_price is None: return

        df = self.options_df.copy()
        
        # 存储最新的平均 IV（用于观察 Vanna 效应）
        valid_ivs = df[df['iv'] > 0]['iv']
        if not valid_ivs.empty:
            self.last_avg_iv = valid_ivs.mean()
        else:
            self.last_avg_iv = getattr(self, 'last_avg_iv', 0)

        # 实时 OI 估算 (昨日 OI + 今日成交量)
        df['rt_oi'] = df['openInterest'].fillna(0) + df['volume'].fillna(0)
        
        # GEX 计算：OI * Gamma * 100 * Spot
        # Put 的贡献设为负值以反映对冲压力
        df['gex'] = df['rt_oi'] * df['gamma'] * 100 * self.spy_spot_price
        df.loc[df['right'] == 'P', 'gex'] *= -1
        
        self.gex_profile = df.groupby('strike')['gex'].sum()
        # 1. 执行信号引擎并获取结果
        results = self.run_signal_engine()
        
        # 2. 统一分发输出：实时快照、历史 CSV、控制台打印
        if results:
            self.update_outputs(results)

    def get_market_internals(self):
        """获取 TICK 和 TRIN 的当前值"""
        # 查找订阅中的 tickers
        tick_val = next((t.last for t in self.ib.tickers() if t.contract.symbol == 'TICK-NYSE'), 0)
        trin_val = next((t.last for t in self.ib.tickers() if t.contract.symbol == 'TRIN-NYSE'), 1.0)
        return tick_val, trin_val
    
    def run_signal_engine(self):
        if self.gex_profile.empty: return
        tick, trin = self.get_market_internals()
        # 1. 计算 Gamma Flip Point (GEX 符号切换点)
        total_gex = self.gex_profile.sum()
        flip_point = None
        sorted_gex = self.gex_profile.sort_index()
        for i in range(len(sorted_gex)-1):
            if sorted_gex.iloc[i] < 0 and sorted_gex.iloc[i+1] > 0:
                flip_point = sorted_gex.index[i]
                break

        # 2. 核心交易逻辑 (左脚踩右脚)
        signal = "WAIT"
        action = "Neutral"
        
        if self.spy_spot_price < (flip_point or 0):
            # 价格在 Flip 点下方：潜在的空头挤压区
            signal = "Short Squeeze Potential / Left Foot Step Right Foot"
            action = "Buy CALL (Low Delta/OTM)"
        elif self.spy_spot_price > (flip_point or 9999):
            # 价格在 Flip 点上方：正 Gamma 区，波动受抑
            signal = "Positive GEX - Low Volatility"
            action = "Sell Puts or Butterfly at Sticky Strike"

        # 3. 返回数据
        return {
            "spot": self.spy_spot_price,
            "flip": flip_point,
            "total_gex": total_gex,
            "tick": tick,  # 新增
            "trin": trin,  # 新增
            "signal": signal,
            "action": action,
            "last_avg_iv": self.last_avg_iv
        }

    async def run(self):
        await self.connect()
        await self.setup_contracts_and_data()
        while self.ib.isConnected():
            await asyncio.sleep(1)

if __name__ == "__main__":
    monitor = SPYGEXMonitor(IBKR_HOST, IBKR_PORT, IBKR_CLIENT_ID)
    try:
        asyncio.run(monitor.run())
    except KeyboardInterrupt:
        logging.info("Stopped by user.")
    finally:
        monitor.ib.disconnect()